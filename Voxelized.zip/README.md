# UnityMeshVoxelizer
A naive mesh voxelizer for Unity. Read the accompanying blog post [here](https://bronsonzgeb.com/index.php/2021/05/15/simple-mesh-voxelization-in-unity/).

![Example](https://github.com/bzgeb/UnityMeshVoxelizer/blob/main/Screenshots/VoxelizedMeshInUnity.png)
